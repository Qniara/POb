﻿using System.Collections.Generic;
using System;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using System.Linq;
using Poprawa.src.Enums;
using Poprawa.src.Models;
using Poprawa.src.Services;
internal class Program {

    public delegate void FileOperation(string filePath);
    static void Main(string[] args) {

        PasswordManager.PasswordVerified += (username, success) => Console.WriteLine($"Logowanie użytkownika {username}: {(success ? "udane" : "nieudane")}");

        InitializeDefaultUsers();

        bool exitProgram = false;

        while (!exitProgram) {

            Console.Clear();

            Console.WriteLine("=== System logowania ===");

            Console.Write("\nWprowadź nazwę użytkownika:");

            string username = Console.ReadLine();

            Console.Write("\nWprowadź hasło:");

            string password = Console.ReadLine();

            if (!PasswordManager.VerifyPassword(username, password)) {

                Console.WriteLine("Niepoprawna nazwa użytkownika lub hasło");

                Console.ReadKey();

                continue;

            }

            var user = new User(username);

            AssignRoleToUser(username, user);



            var rbacSystem = new RBAC();

            string filePath = "testFile.txt";

            bool logout = false;
            while (!logout) {

                Console.Clear();

                Console.WriteLine($"Zalogowano jako: {username}");

                Console.WriteLine("\nWybierz opcję:");

                DisplayMenuOptions(rbacSystem, user);

                if (!int.TryParse(Console.ReadLine(), out int choice)) {

                    Console.WriteLine("Niepoprawny wybór. Spróbuj ponownie");

                    continue;

                }

                logout = HandleUserChoice(choice, rbacSystem, user, filePath, ref exitProgram);

            }

        }

        Console.WriteLine("Dziękujemy za skorzystanie z programu");

    }
    private static void InitializeDefaultUsers() {

        PasswordManager.SavePassword("admin", "pass");

        PasswordManager.SavePassword("manager", "pass");

        PasswordManager.SavePassword("normalUser", "pass");

        PasswordManager.SavePassword("xyz", "pass");

    }



    private static void AssignRoleToUser(string username, User user) {

        if (username == "admin") user.AddRole(Role.Administrator);

        else if (username == "manager") user.AddRole(Role.Manager);

        else if (username == "normalUser") user.AddRole(Role.User);

    }



    private static void DisplayMenuOptions(RBAC rbacSystem, User user) {

        if (rbacSystem.HasPermission(user, Permission.Read)) Console.WriteLine("1. Odczytaj plik");

        if (rbacSystem.HasPermission(user, Permission.Write)) Console.WriteLine("2. Zapisz do pliku");

        if (rbacSystem.HasPermission(user, Permission.Delete)) Console.WriteLine("3. Modyfikuj plik");

        if (rbacSystem.HasPermission(user, Permission.ManageUsers)) Console.WriteLine("4. Dodaj nowego użytkownika");

        Console.WriteLine("5. Wyloguj się");

        Console.WriteLine("6. Wyjdź z programu");

    }



    private static bool HandleUserChoice(int choice, RBAC rbacSystem, User user, string filePath, ref bool exitProgram) {

        switch (choice) {

            case 1:

                FileManager.ReadFile(filePath);

                break;

            case 2:

                if (rbacSystem.HasPermission(user, Permission.Write)) FileManager.WriteToFile(filePath);

                else Console.WriteLine("Nie masz uprawnień");

                break;

            case 3:

                if (rbacSystem.HasPermission(user, Permission.Delete)) FileManager.ModifyFile(filePath);

                else Console.WriteLine("Nie masz uprawnień");

                break;

            case 4:

                if (rbacSystem.HasPermission(user, Permission.ManageUsers)) FileManager.AddNewUser();

                else Console.WriteLine("Nie masz uprawnień");

                break;

            case 5:

                Console.WriteLine("Wylogowano");

                return true;

            case 6:

                Console.WriteLine("Zamykanie programu");

                exitProgram = true;

                return true;

            default:

                Console.WriteLine("Niepoprawny wybór");

                break;

        }



        Console.WriteLine("\nNaciśnij dowolny klawisz, aby kontynuować");

        Console.ReadKey();

        return false;

    }

}

